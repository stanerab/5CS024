// Function to show the booking pop-up
function showBookingPopup() {
    var bookingPopup = document.getElementById("bookingPopup");
    bookingPopup.style.display = "block";
}

// Function to close the pop-up
function closePopup(popupId) {
    var popup = document.getElementById(popupId);
    popup.style.display = "none";
}

// Function to submit the booking
function submitBooking() {
    // Get the form inputs
    var name = document.getElementById("bookingName").value;
    var surname = document.getElementById("bookingSurname").value;
    var date = document.getElementById("bookingDate").value;
    
    // Here you can perform validation and further processing if needed
    
    // Redirect to booking.html with query parameters
    window.location.href = "booking.html?name=" + encodeURIComponent(name) + "&surname=" + encodeURIComponent(surname) + "&date=" + encodeURIComponent(date);
}

// Function to add an item to the basket
function addToBasket(itemName, price) {
    var basket = JSON.parse(localStorage.getItem("basket")) || [];
    basket.push({ name: itemName, price: price });
    localStorage.setItem("basket", JSON.stringify(basket));
}

// Function to display items in the basket
function displayBasket() {
    var basket = JSON.parse(localStorage.getItem("basket")) || [];
    var basketContainer = document.getElementById("basketContainer");
    basketContainer.innerHTML = ""; // Clear previous content
    
    basket.forEach(function(item, index) {
        var itemDiv = document.createElement("div");
        itemDiv.innerHTML = "<p>" + item.name + " - £" + item.price.toFixed(2) + "</p><button onclick=\"removeFromBasket(" + index + ")\">Remove</button>";
        basketContainer.appendChild(itemDiv);
    });
}

// Function to remove an item from the basket
function removeFromBasket(index) {
    var basket = JSON.parse(localStorage.getItem("basket")) || [];
    basket.splice(index, 1);
    localStorage.setItem("basket", JSON.stringify(basket));
    displayBasket(); // Refresh the basket display
}

// Call displayBasket() when the page loads to show the initial basket content
window.onload = displayBasket;

function checkout() {
    window.location.href = "checkout.html";
}

